package Domain;

public class User {
	
	private int id;
    private String name;
    private String Aadhar;
    private String status;
    private String password;
    public User(){}
	public User( int l,String name,String Aadhar,String status, String password) {
		
		this.id=l;
        this.name=name;
        this.Aadhar=Aadhar;
        this.status=status;
        this.password=password;
	}
	
	public User(String name,String Aadhar,String password){
        this.name = name;
        this.Aadhar = Aadhar;
        this.password = password;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAadhar() {
		return Aadhar;
	}

	public void setAadhar(String Aadhar) {
		this.Aadhar = Aadhar;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
